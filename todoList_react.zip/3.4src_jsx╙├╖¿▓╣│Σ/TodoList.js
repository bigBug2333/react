import React, {Component} from 'react';
import './style.css'

class TodoList extends Component {

    // 构造器
    constructor(props){
        super(props);               //接受父类的props
        this.state = {
            inputValue: '',         //输入框的值
            list: []                //列表中的每一项
        };

        // this.handleInputChange = this.handleInputChange.bind(this)
    }

    render() {
        return (
            <div>
                <div>
                    <label htmlFor="insertArea">输入内容</label>
                    <input
                        id='insertArea'
                        type="text"
                           className="input"
                           value={this.state.inputValue}    //1.绑定状态
                        onChange = {this.handleInputChange.bind(this)}       //2.onChange事件
                    />
                    <button onClick = {this.handleBtnClick.bind(this)}>提交</button>
                </div>
                < ul>
                    {this.state.list.map((item, index) =>{
                        return (
                            <li key={index}
                            onClick={this.handleItemDelete.bind(this, index)}
                                dangerouslySetInnerHTML={{__html: item}}
                            >
                            </li>
                        )
                    })}
                </ul>
            </div>
        );
    }
    // 1.可以再input显示输入内容
    handleInputChange(e) {
        this.setState({inputValue : e.target.value})
    }

    // 2.点击按钮添加至列表事件
    handleBtnClick(e) {
        this.setState({
            list : [...this.state.list, this.state.inputValue],
            inputValue : ""
        })
    }

    // 3.点击列表项删除当前项
    // immutable:不可以直接修改state
    handleItemDelete(index) {
        const list = [...this.state.list];
        list.splice(index, 1);
        this.setState({
            list : list
        })
    }
}

export default TodoList;