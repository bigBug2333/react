import React, {Component} from 'react';
import TodoItem from './TodoItem.js'
import './style.css';

class TodoList extends Component {

    // 构造器
    constructor(props) {
        super(props);               //接受父类的props
        this.state = {
            inputValue: '',         //输入框的值
            list: []                //列表中的每一项
        };

        this.handleInputChange = this.handleInputChange.bind(this);
        this.handleBtnClick = this.handleBtnClick.bind(this);
        this.handleItemDelete = this.handleItemDelete.bind(this);

    }

    render() {
        return (
            <div>
                <div>
                    <label htmlFor="insertArea">输入内容</label>
                    <input
                        id='insertArea'
                        type="text"
                        className="input"
                        value={this.state.inputValue}    //1.绑定状态
                        onChange={this.handleInputChange}       //2.onChange事件
                    />
                    <button onClick={this.handleBtnClick}>提交</button>
                </div>
                < ul>
                    {this.getTodoItem()}
                </ul>
            </div>
        );
    }

    getTodoItem() {
        return (
            this.state.list.map((item, index) => {
                return (
                    <TodoItem
                        key={index}
                        content={item}
                        index={index}
                        deleteItem={this.handleItemDelete}
                    />
                )
            })
        )
    }

    // 1.可以再input显示输入内容
    handleInputChange(e) {
        const value = e.target.value;
        this.setState(() => ({
                inputValue: value
            })
        )
    }

    // 2.点击按钮添加至列表事件
    handleBtnClick(e) {
        this.setState((prevState) => ({                     //prevState:修改之前的状态
                list: [...prevState.list, prevState.inputValue],
                inputValue: ""
            })
        )
    }

    // 3.点击列表项删除当前项
    // immutable:不可以直接修改state
    handleItemDelete(index) {
        this.setState((prevState) => {
            const list = [...prevState.list];
            list.splice(index, 1);
            return {list}
        })
        // const list = [...this.state.list];
        // list.splice(index, 1);
        // this.setState({
        //     list: list
        // })
    }
}

export default TodoList;