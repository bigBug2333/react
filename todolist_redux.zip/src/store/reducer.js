const defaultState = {
    inputValue: '1',
    list: []
};

export default (state = defaultState, action)=> {
    return state;
}