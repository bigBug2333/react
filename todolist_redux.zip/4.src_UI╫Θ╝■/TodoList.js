import React, {Component} from 'react';
import 'antd/dist/antd.css'
import store from './store'
// import {CHANGE_INPUT_VALUE,
//     ADD_TODO_ITEM,
//     DELETE_TODO_ITEM
// } from './store/actionTypes'
import {getInputChangeAction,
    getAddItemAction,
    getDeleteItemAction
} from './store/actionCreators'
import TodoListUI from "./TodoListUI"

class TodoList extends Component {

    // 构造器
    constructor(props){
        super(props);               //接受父类的props
        this.state = store.getState();

        this.handleInputChange = this.handleInputChange.bind(this);
        this.handleStoreChange = this.handleStoreChange.bind(this);
        this.handleBtnClick = this.handleBtnClick.bind(this);
        this.handleItemDelete = this.handleItemDelete.bind(this);
        // 3.store一经改变，subscribe的函数自动执行
        store.subscribe(this.handleStoreChange)
    }

    render() {
        return (
            <TodoListUI
                inputValue={this.state.inputValue}
                handleInputChange={this.handleInputChange}
                handleBtnClick={this.handleBtnClick}
                list={this.state.list}
                handleItemDelete={this.handleItemDelete}
            />
        );
    }

    handleInputChange(e){
        // 1.创建一个action
        // const action = {
        //     type: CHANGE_INPUT_VALUE,
        //     value: e.target.value
        // };
        const action = getInputChangeAction(e.target.value);
        store.dispatch(action)
    }

    handleStoreChange() {
        this.setState(store.getState())
    }

    handleBtnClick(e) {
        // const action = {
        //     type: ADD_TODO_ITEM,
        //     value: e.target.value
        // };
        const action = getAddItemAction(e.target.value);


        store.dispatch(action)
    }

    handleItemDelete(index) {
        // const action = {
        //     type: DELETE_TODO_ITEM,
        //     index
        // };
        const action = getDeleteItemAction(index);
        store.dispatch(action)
    }
}



export default TodoList;