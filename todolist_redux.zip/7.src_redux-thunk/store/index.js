import {createStore} from "redux";
import reducer from './reducers'                    // 笔记本传递给store
import thunk from 'redux-thunk'

const composeEnhancers = window.__REDUX_DEVTOOLS_EXTENSION__COMPOSE__ ?
    window.__REDUX_DEVTOOLS_EXTENSION__COMPOSE__({}):compose;

const enhancer = composeEnhancers(
    applyMiddleware(thunk),
);

const store = createStore(reducer, enhancer);

// const store = createStore(reducer,
    // applyMiddleware([thunk,window.__REDUX_DEVTOOLS_EXTENSION__ && window.__REDUX_DEVTOOLS_EXTENSION__()]),
    // window.__REDUX_DEVTOOLS_EXTENSION__ && window.__REDUX_DEVTOOLS_EXTENSION__()
    //如果页面上安装了react_devTools，就在页面上使用这个工具
// );

export default store

// 1.store是唯一的，只有store可以改变自己的值
// 2.Reducer必须是纯函数(给定固定的输入就一定会有固定的输出，而且不会有任何的副作用)
// 3.Redux中的核心的API：
    // createStore：帮助我们创建store
    // store.dispatch：帮助我们派发一个Action，这个action会传递给store
// 4.store.getState：可以帮助我们获取store里面所有的数据内容
// 5.store.subscribe：可以帮助我们监视store的改变，只要改变store.subscribe的回调函数就会被执行